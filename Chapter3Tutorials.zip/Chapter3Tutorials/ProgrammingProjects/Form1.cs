﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingProjects
{
    public partial class tipTaxCalculator : Form
    {
        //Constant field

        const double TAX_RATE_VALUE = 0.07;
        const double TIP_PERCENT_VALUE = 0.15;


        public tipTaxCalculator()
        {
            InitializeComponent();
        }

        private void taxOutputLabel_Click(object sender, EventArgs e)
        {
            
            
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Declare the variable

            double billAmount;
            double tax;
            double tip;
            double total;
          

            //Assigning value to the billAmount varibale.
              billAmount = double.Parse(billAmountTextBox.Text);

            //Assigning value to the taxAmount varibale
              tax = billAmount * TAX_RATE_VALUE;

            //Dispaly the tax amount on the taxOutputLabel.
              taxOutputLabel.Text = tax.ToString();

            //Assigning varibale to the tip variable.
             tip = billAmount * TIP_PERCENT_VALUE;

            //Display the tip amount on the tipOutputLabel.
             tipOutputlabel.Text = tip.ToString();

            //Assigning value to the total variable.
              total = billAmount + tax + tip;

            //Display the grand total amount 
              displayOutputTotalLabel.Text = total.ToString();
           
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear all the output and input controls.
                billAmountTextBox.Text = "";
                taxOutputLabel.Text = "";
                tipOutputlabel.Text = "";
                displayOutputTotalLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form.
               this.Close();
        }
    }
}
