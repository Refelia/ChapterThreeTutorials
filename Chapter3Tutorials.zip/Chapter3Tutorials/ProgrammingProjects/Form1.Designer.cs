﻿namespace ProgrammingProjects
{
    partial class tipTaxCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.billAmountLabel = new System.Windows.Forms.Label();
            this.taxAmountLabel = new System.Windows.Forms.Label();
            this.tipAmountLabel = new System.Windows.Forms.Label();
            this.displayOutputTotalLabel = new System.Windows.Forms.Label();
            this.tipOutputlabel = new System.Windows.Forms.Label();
            this.taxOutputLabel = new System.Windows.Forms.Label();
            this.totalAmountLabel = new System.Windows.Forms.Label();
            this.billAmountTextBox = new System.Windows.Forms.TextBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 0;
            // 
            // billAmountLabel
            // 
            this.billAmountLabel.AutoSize = true;
            this.billAmountLabel.Location = new System.Drawing.Point(42, 39);
            this.billAmountLabel.Name = "billAmountLabel";
            this.billAmountLabel.Size = new System.Drawing.Size(62, 13);
            this.billAmountLabel.TabIndex = 1;
            this.billAmountLabel.Text = "Bill Amount:";
            // 
            // taxAmountLabel
            // 
            this.taxAmountLabel.AutoSize = true;
            this.taxAmountLabel.Location = new System.Drawing.Point(76, 76);
            this.taxAmountLabel.Name = "taxAmountLabel";
            this.taxAmountLabel.Size = new System.Drawing.Size(28, 13);
            this.taxAmountLabel.TabIndex = 2;
            this.taxAmountLabel.Text = "Tax:";
            // 
            // tipAmountLabel
            // 
            this.tipAmountLabel.AutoSize = true;
            this.tipAmountLabel.Location = new System.Drawing.Point(79, 115);
            this.tipAmountLabel.Name = "tipAmountLabel";
            this.tipAmountLabel.Size = new System.Drawing.Size(25, 13);
            this.tipAmountLabel.TabIndex = 3;
            this.tipAmountLabel.Text = "Tip:";
            // 
            // displayOutputTotalLabel
            // 
            this.displayOutputTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.displayOutputTotalLabel.Location = new System.Drawing.Point(110, 156);
            this.displayOutputTotalLabel.Name = "displayOutputTotalLabel";
            this.displayOutputTotalLabel.Size = new System.Drawing.Size(179, 23);
            this.displayOutputTotalLabel.TabIndex = 4;
            this.displayOutputTotalLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tipOutputlabel
            // 
            this.tipOutputlabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tipOutputlabel.Location = new System.Drawing.Point(110, 115);
            this.tipOutputlabel.Name = "tipOutputlabel";
            this.tipOutputlabel.Size = new System.Drawing.Size(179, 23);
            this.tipOutputlabel.TabIndex = 5;
            this.tipOutputlabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // taxOutputLabel
            // 
            this.taxOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.taxOutputLabel.Location = new System.Drawing.Point(110, 76);
            this.taxOutputLabel.Name = "taxOutputLabel";
            this.taxOutputLabel.Size = new System.Drawing.Size(179, 23);
            this.taxOutputLabel.TabIndex = 6;
            this.taxOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.taxOutputLabel.Click += new System.EventHandler(this.taxOutputLabel_Click);
            // 
            // totalAmountLabel
            // 
            this.totalAmountLabel.AutoSize = true;
            this.totalAmountLabel.Location = new System.Drawing.Point(70, 166);
            this.totalAmountLabel.Name = "totalAmountLabel";
            this.totalAmountLabel.Size = new System.Drawing.Size(34, 13);
            this.totalAmountLabel.TabIndex = 7;
            this.totalAmountLabel.Text = "Total:";
            // 
            // billAmountTextBox
            // 
            this.billAmountTextBox.Location = new System.Drawing.Point(110, 39);
            this.billAmountTextBox.Name = "billAmountTextBox";
            this.billAmountTextBox.Size = new System.Drawing.Size(179, 20);
            this.billAmountTextBox.TabIndex = 8;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(39, 226);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 9;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(177, 226);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 10;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(320, 226);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // tipTaxCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(444, 261);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.billAmountTextBox);
            this.Controls.Add(this.totalAmountLabel);
            this.Controls.Add(this.taxOutputLabel);
            this.Controls.Add(this.tipOutputlabel);
            this.Controls.Add(this.displayOutputTotalLabel);
            this.Controls.Add(this.tipAmountLabel);
            this.Controls.Add(this.taxAmountLabel);
            this.Controls.Add(this.billAmountLabel);
            this.Controls.Add(this.label1);
            this.Name = "tipTaxCalculator";
            this.Text = "Tip, Tax and Total";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label billAmountLabel;
        private System.Windows.Forms.Label taxAmountLabel;
        private System.Windows.Forms.Label tipAmountLabel;
        private System.Windows.Forms.Label displayOutputTotalLabel;
        private System.Windows.Forms.Label tipOutputlabel;
        private System.Windows.Forms.Label taxOutputLabel;
        private System.Windows.Forms.Label totalAmountLabel;
        private System.Windows.Forms.TextBox billAmountTextBox;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

