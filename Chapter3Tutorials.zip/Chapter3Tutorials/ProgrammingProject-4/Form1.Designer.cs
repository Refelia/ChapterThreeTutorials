﻿namespace ProgrammingProject_4
{
    partial class totalSalesTax
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.purchaseAmountLabel = new System.Windows.Forms.Label();
            this.totalSalesLabel = new System.Windows.Forms.Label();
            this.salesTotallabelOutput = new System.Windows.Forms.Label();
            this.stateSalesTaxLabelOutput = new System.Windows.Forms.Label();
            this.countySalesTaxLabelOutput = new System.Windows.Forms.Label();
            this.totalPurchaseLabel = new System.Windows.Forms.Label();
            this.totalSalesTaxLabel = new System.Windows.Forms.Label();
            this.countySalesTaxLabel = new System.Windows.Forms.Label();
            this.stateSalesTaxLabel = new System.Windows.Forms.Label();
            this.totalPurchaseLabelOutput = new System.Windows.Forms.Label();
            this.totalSalesLabelOutput = new System.Windows.Forms.Label();
            this.purchaseAmountTextBox = new System.Windows.Forms.TextBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // purchaseAmountLabel
            // 
            this.purchaseAmountLabel.AutoSize = true;
            this.purchaseAmountLabel.Location = new System.Drawing.Point(37, 32);
            this.purchaseAmountLabel.Name = "purchaseAmountLabel";
            this.purchaseAmountLabel.Size = new System.Drawing.Size(94, 13);
            this.purchaseAmountLabel.TabIndex = 0;
            this.purchaseAmountLabel.Text = "Purchase Amount:";
            // 
            // totalSalesLabel
            // 
            this.totalSalesLabel.AutoSize = true;
            this.totalSalesLabel.Location = new System.Drawing.Point(72, 259);
            this.totalSalesLabel.Name = "totalSalesLabel";
            this.totalSalesLabel.Size = new System.Drawing.Size(59, 13);
            this.totalSalesLabel.TabIndex = 1;
            this.totalSalesLabel.Text = "Sales total:";
            // 
            // salesTotallabelOutput
            // 
            this.salesTotallabelOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.salesTotallabelOutput.Location = new System.Drawing.Point(137, 254);
            this.salesTotallabelOutput.Name = "salesTotallabelOutput";
            this.salesTotallabelOutput.Size = new System.Drawing.Size(241, 23);
            this.salesTotallabelOutput.TabIndex = 2;
            this.salesTotallabelOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // stateSalesTaxLabelOutput
            // 
            this.stateSalesTaxLabelOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.stateSalesTaxLabelOutput.Location = new System.Drawing.Point(137, 100);
            this.stateSalesTaxLabelOutput.Name = "stateSalesTaxLabelOutput";
            this.stateSalesTaxLabelOutput.Size = new System.Drawing.Size(189, 23);
            this.stateSalesTaxLabelOutput.TabIndex = 3;
            this.stateSalesTaxLabelOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // countySalesTaxLabelOutput
            // 
            this.countySalesTaxLabelOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.countySalesTaxLabelOutput.Location = new System.Drawing.Point(137, 64);
            this.countySalesTaxLabelOutput.Name = "countySalesTaxLabelOutput";
            this.countySalesTaxLabelOutput.Size = new System.Drawing.Size(189, 23);
            this.countySalesTaxLabelOutput.TabIndex = 4;
            this.countySalesTaxLabelOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalPurchaseLabel
            // 
            this.totalPurchaseLabel.AutoSize = true;
            this.totalPurchaseLabel.Location = new System.Drawing.Point(49, 186);
            this.totalPurchaseLabel.Name = "totalPurchaseLabel";
            this.totalPurchaseLabel.Size = new System.Drawing.Size(82, 13);
            this.totalPurchaseLabel.TabIndex = 5;
            this.totalPurchaseLabel.Text = "Total Purchase:";
            // 
            // totalSalesTaxLabel
            // 
            this.totalSalesTaxLabel.AutoSize = true;
            this.totalSalesTaxLabel.Location = new System.Drawing.Point(253, 192);
            this.totalSalesTaxLabel.Name = "totalSalesTaxLabel";
            this.totalSalesTaxLabel.Size = new System.Drawing.Size(73, 13);
            this.totalSalesTaxLabel.TabIndex = 6;
            this.totalSalesTaxLabel.Text = "Total sale tax:";
            // 
            // countySalesTaxLabel
            // 
            this.countySalesTaxLabel.AutoSize = true;
            this.countySalesTaxLabel.Location = new System.Drawing.Point(44, 69);
            this.countySalesTaxLabel.Name = "countySalesTaxLabel";
            this.countySalesTaxLabel.Size = new System.Drawing.Size(87, 13);
            this.countySalesTaxLabel.TabIndex = 7;
            this.countySalesTaxLabel.Text = "County sales tax:";
            // 
            // stateSalesTaxLabel
            // 
            this.stateSalesTaxLabel.AutoSize = true;
            this.stateSalesTaxLabel.Location = new System.Drawing.Point(52, 110);
            this.stateSalesTaxLabel.Name = "stateSalesTaxLabel";
            this.stateSalesTaxLabel.Size = new System.Drawing.Size(79, 13);
            this.stateSalesTaxLabel.TabIndex = 8;
            this.stateSalesTaxLabel.Text = "State sales tax:";
            // 
            // totalPurchaseLabelOutput
            // 
            this.totalPurchaseLabelOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalPurchaseLabelOutput.Location = new System.Drawing.Point(137, 180);
            this.totalPurchaseLabelOutput.Name = "totalPurchaseLabelOutput";
            this.totalPurchaseLabelOutput.Size = new System.Drawing.Size(94, 25);
            this.totalPurchaseLabelOutput.TabIndex = 9;
            this.totalPurchaseLabelOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalSalesLabelOutput
            // 
            this.totalSalesLabelOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalSalesLabelOutput.Location = new System.Drawing.Point(332, 180);
            this.totalSalesLabelOutput.Name = "totalSalesLabelOutput";
            this.totalSalesLabelOutput.Size = new System.Drawing.Size(96, 25);
            this.totalSalesLabelOutput.TabIndex = 10;
            this.totalSalesLabelOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // purchaseAmountTextBox
            // 
            this.purchaseAmountTextBox.Location = new System.Drawing.Point(137, 24);
            this.purchaseAmountTextBox.Name = "purchaseAmountTextBox";
            this.purchaseAmountTextBox.Size = new System.Drawing.Size(189, 20);
            this.purchaseAmountTextBox.TabIndex = 11;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(375, 41);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 12;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(375, 105);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 13;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // totalSalesTax
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(489, 300);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.purchaseAmountTextBox);
            this.Controls.Add(this.totalSalesLabelOutput);
            this.Controls.Add(this.totalPurchaseLabelOutput);
            this.Controls.Add(this.stateSalesTaxLabel);
            this.Controls.Add(this.countySalesTaxLabel);
            this.Controls.Add(this.totalSalesTaxLabel);
            this.Controls.Add(this.totalPurchaseLabel);
            this.Controls.Add(this.countySalesTaxLabelOutput);
            this.Controls.Add(this.stateSalesTaxLabelOutput);
            this.Controls.Add(this.salesTotallabelOutput);
            this.Controls.Add(this.totalSalesLabel);
            this.Controls.Add(this.purchaseAmountLabel);
            this.Name = "totalSalesTax";
            this.Text = "Sales Tax and Total";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label purchaseAmountLabel;
        private System.Windows.Forms.Label totalSalesLabel;
        private System.Windows.Forms.Label salesTotallabelOutput;
        private System.Windows.Forms.Label stateSalesTaxLabelOutput;
        private System.Windows.Forms.Label countySalesTaxLabelOutput;
        private System.Windows.Forms.Label totalPurchaseLabel;
        private System.Windows.Forms.Label totalSalesTaxLabel;
        private System.Windows.Forms.Label countySalesTaxLabel;
        private System.Windows.Forms.Label stateSalesTaxLabel;
        private System.Windows.Forms.Label totalPurchaseLabelOutput;
        private System.Windows.Forms.Label totalSalesLabelOutput;
        private System.Windows.Forms.TextBox purchaseAmountTextBox;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button exitButton;
    }
}

