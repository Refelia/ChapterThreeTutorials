﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingProject_4
{
    public partial class totalSalesTax : Form
    {
        //Constant field.
        const double STATE_SALES_TAX_VALUE = 0.04;
        const double COUNTY_SALES_TAX_VALUE = 0.02;

        public totalSalesTax()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Declare the variable and their value.
            double amount = double.Parse(purchaseAmountTextBox.Text);

            //Declare a variable and their value.
            double stateTax = amount * STATE_SALES_TAX_VALUE;

            //Display the calculated state tax from the purchase amount
            stateSalesTaxLabelOutput.Text = stateTax.ToString();

            //Declare a varibale for county tax.
            double countyTax = amount * COUNTY_SALES_TAX_VALUE;

            //Display the calculated tax amount from the purchase amount.
            countySalesTaxLabelOutput.Text = countyTax.ToString();

            //Declare a varibale for total tax.
            double totalTax = stateTax + countyTax;

            //Display the calculated amount from the total sales tax.
            totalSalesLabelOutput.Text = totalTax.ToString();

            //Declare  a variable and set their value
            double TotalPurchase = (amount + stateTax + countyTax) - totalTax;

            //Display the result of the total purchase before tax.
            totalPurchaseLabelOutput.Text = TotalPurchase.ToString();

            //Declare varible and set the value .
            double salesTotal = totalTax + TotalPurchase;

            //Display the total sales.
            salesTotallabelOutput.Text = salesTotal.ToString();
            


        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }
}
