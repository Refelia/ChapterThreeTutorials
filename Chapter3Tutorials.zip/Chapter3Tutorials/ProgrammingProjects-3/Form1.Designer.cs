﻿namespace ProgrammingProjects_3
{
    partial class distanceTraveled
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.speedLabel = new System.Windows.Forms.Label();
            this.distanceLabel = new System.Windows.Forms.Label();
            this.totalDistanceTravelLabel = new System.Windows.Forms.Label();
            this.distanceTravel12Hrs = new System.Windows.Forms.Label();
            this.distanceTravel8Hrslabel = new System.Windows.Forms.Label();
            this.distanceTravel5HrsLabel = new System.Windows.Forms.Label();
            this.outputDistnceTravel8HrsLabel = new System.Windows.Forms.Label();
            this.outputdistTravel12HrsLabel = new System.Windows.Forms.Label();
            this.outputDistanceTravel5HrsLabel = new System.Windows.Forms.Label();
            this.carSpeedTextBox = new System.Windows.Forms.TextBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // speedLabel
            // 
            this.speedLabel.AutoSize = true;
            this.speedLabel.Location = new System.Drawing.Point(12, 34);
            this.speedLabel.Name = "speedLabel";
            this.speedLabel.Size = new System.Drawing.Size(115, 13);
            this.speedLabel.TabIndex = 0;
            this.speedLabel.Text = "Enter your car\'s speed:";
            // 
            // distanceLabel
            // 
            this.distanceLabel.AutoSize = true;
            this.distanceLabel.Location = new System.Drawing.Point(75, 153);
            this.distanceLabel.Name = "distanceLabel";
            this.distanceLabel.Size = new System.Drawing.Size(122, 13);
            this.distanceLabel.TabIndex = 1;
            this.distanceLabel.Text = "Total Distance travelled:";
            // 
            // totalDistanceTravelLabel
            // 
            this.totalDistanceTravelLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalDistanceTravelLabel.Location = new System.Drawing.Point(203, 136);
            this.totalDistanceTravelLabel.Name = "totalDistanceTravelLabel";
            this.totalDistanceTravelLabel.Size = new System.Drawing.Size(198, 30);
            this.totalDistanceTravelLabel.TabIndex = 2;
            this.totalDistanceTravelLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // distanceTravel12Hrs
            // 
            this.distanceTravel12Hrs.AutoSize = true;
            this.distanceTravel12Hrs.Location = new System.Drawing.Point(258, 76);
            this.distanceTravel12Hrs.Name = "distanceTravel12Hrs";
            this.distanceTravel12Hrs.Size = new System.Drawing.Size(136, 13);
            this.distanceTravel12Hrs.TabIndex = 3;
            this.distanceTravel12Hrs.Text = "Distance travel in 12 hours:";
            // 
            // distanceTravel8Hrslabel
            // 
            this.distanceTravel8Hrslabel.AutoSize = true;
            this.distanceTravel8Hrslabel.Location = new System.Drawing.Point(264, 34);
            this.distanceTravel8Hrslabel.Name = "distanceTravel8Hrslabel";
            this.distanceTravel8Hrslabel.Size = new System.Drawing.Size(130, 13);
            this.distanceTravel8Hrslabel.TabIndex = 4;
            this.distanceTravel8Hrslabel.Text = "Distance travel in 8 hours:";
            // 
            // distanceTravel5HrsLabel
            // 
            this.distanceTravel5HrsLabel.AutoSize = true;
            this.distanceTravel5HrsLabel.Location = new System.Drawing.Point(2, 76);
            this.distanceTravel5HrsLabel.Name = "distanceTravel5HrsLabel";
            this.distanceTravel5HrsLabel.Size = new System.Drawing.Size(125, 13);
            this.distanceTravel5HrsLabel.TabIndex = 5;
            this.distanceTravel5HrsLabel.Text = "Distance travel in 5 hour:";
            // 
            // outputDistnceTravel8HrsLabel
            // 
            this.outputDistnceTravel8HrsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputDistnceTravel8HrsLabel.Location = new System.Drawing.Point(400, 18);
            this.outputDistnceTravel8HrsLabel.Name = "outputDistnceTravel8HrsLabel";
            this.outputDistnceTravel8HrsLabel.Size = new System.Drawing.Size(93, 29);
            this.outputDistnceTravel8HrsLabel.TabIndex = 6;
            this.outputDistnceTravel8HrsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // outputdistTravel12HrsLabel
            // 
            this.outputdistTravel12HrsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputdistTravel12HrsLabel.Location = new System.Drawing.Point(400, 61);
            this.outputdistTravel12HrsLabel.Name = "outputdistTravel12HrsLabel";
            this.outputdistTravel12HrsLabel.Size = new System.Drawing.Size(93, 28);
            this.outputdistTravel12HrsLabel.TabIndex = 7;
            this.outputdistTravel12HrsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // outputDistanceTravel5HrsLabel
            // 
            this.outputDistanceTravel5HrsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputDistanceTravel5HrsLabel.Location = new System.Drawing.Point(133, 62);
            this.outputDistanceTravel5HrsLabel.Name = "outputDistanceTravel5HrsLabel";
            this.outputDistanceTravel5HrsLabel.Size = new System.Drawing.Size(83, 27);
            this.outputDistanceTravel5HrsLabel.TabIndex = 8;
            this.outputDistanceTravel5HrsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // carSpeedTextBox
            // 
            this.carSpeedTextBox.Location = new System.Drawing.Point(133, 27);
            this.carSpeedTextBox.Name = "carSpeedTextBox";
            this.carSpeedTextBox.Size = new System.Drawing.Size(83, 20);
            this.carSpeedTextBox.TabIndex = 9;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(52, 229);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 10;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(230, 229);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 11;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(391, 229);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 12;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // distanceTraveled
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(559, 295);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.carSpeedTextBox);
            this.Controls.Add(this.outputDistanceTravel5HrsLabel);
            this.Controls.Add(this.outputdistTravel12HrsLabel);
            this.Controls.Add(this.outputDistnceTravel8HrsLabel);
            this.Controls.Add(this.distanceTravel5HrsLabel);
            this.Controls.Add(this.distanceTravel8Hrslabel);
            this.Controls.Add(this.distanceTravel12Hrs);
            this.Controls.Add(this.totalDistanceTravelLabel);
            this.Controls.Add(this.distanceLabel);
            this.Controls.Add(this.speedLabel);
            this.Name = "distanceTraveled";
            this.Text = "Distance Traveled";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label speedLabel;
        private System.Windows.Forms.Label distanceLabel;
        private System.Windows.Forms.Label totalDistanceTravelLabel;
        private System.Windows.Forms.Label distanceTravel12Hrs;
        private System.Windows.Forms.Label distanceTravel8Hrslabel;
        private System.Windows.Forms.Label distanceTravel5HrsLabel;
        private System.Windows.Forms.Label outputDistnceTravel8HrsLabel;
        private System.Windows.Forms.Label outputdistTravel12HrsLabel;
        private System.Windows.Forms.Label outputDistanceTravel5HrsLabel;
        private System.Windows.Forms.TextBox carSpeedTextBox;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

