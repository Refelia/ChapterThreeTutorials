﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingProjects_3
{
    public partial class distanceTraveled : Form
    {
        public distanceTraveled()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Declare the variable
                double speed;
                double distanceIn5hrs;
                double distanceIn8hrs;
                double distanceIn12hrs;
                double total;

            //Assign a value to the speed variable.
                 speed = double.Parse(carSpeedTextBox.Text);

            //Assign a value to the time.
                distanceIn5hrs = speed * 5;
                distanceIn8hrs =  speed * 8;
                distanceIn12hrs = speed * 12;
            total = speed * distanceIn5hrs;
            total = speed * distanceIn8hrs;
            total = speed * distanceIn12hrs;

            //Display the total distance traveled.
            totalDistanceTravelLabel.Text = total.ToString();


            //Get the distance travel in 5, 8, and 12 hours.
            outputDistanceTravel5HrsLabel.Text = distanceIn5hrs.ToString();
            outputDistnceTravel8HrsLabel.Text = distanceIn8hrs.ToString();
            outputdistTravel12HrsLabel.Text = distanceIn12hrs.ToString();
            
           
             
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear all the input and output control.
            carSpeedTextBox.Text = "";
            outputDistanceTravel5HrsLabel.Text = "";
            outputDistnceTravel8HrsLabel.Text = "";
            outputdistTravel12HrsLabel.Text = "";
            totalDistanceTravelLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //close the form.
            this.Close();
        }
    }
}
