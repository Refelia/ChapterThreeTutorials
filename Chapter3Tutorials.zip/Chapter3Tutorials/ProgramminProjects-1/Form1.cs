﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgramminProjects_1
{
    public partial class nameFormat : Form
    {
        public nameFormat()
        {
            InitializeComponent();
        }

        private void displayNameButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Declare the string variable.

                string result;

                //Concatenate the first name, middle name, last name and title to get the string result.

                result = firstNameTextBox.Text + " " +
                    middleNameTextBox.Text + " " +
                    lastNameTextBox.Text + " " +
                    titleTextBox.Text;

                //Display the result string on the displayResultLabel control.

                displayResultLabel.Text = result;
            }
            catch (Exception aa)
            {
                //Display the default error message.

                MessageBox.Show(aa.Message);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form.

            this.Close();
        }
    }
}
