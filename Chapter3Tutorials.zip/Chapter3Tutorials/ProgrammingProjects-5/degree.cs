﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgrammingProjects_5
{
    class degree
    {
        public double Celsius (double val)
        {
            return (val * 9) / 5 + 32;
        }

        public double Fareignheit (double val)
        {
            return (val - 32) * 5 / 9;
        }
    }
}
