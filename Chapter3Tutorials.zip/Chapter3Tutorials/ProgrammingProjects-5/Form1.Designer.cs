﻿namespace ProgrammingProjects_5
{
    partial class temperatureConverter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.celsiusButton = new System.Windows.Forms.RadioButton();
            this.fareignheitButton = new System.Windows.Forms.RadioButton();
            this.temperaturelabel = new System.Windows.Forms.Label();
            this.degreesOutputLabel = new System.Windows.Forms.Label();
            this.degreesLabel = new System.Windows.Forms.Label();
            this.temperatureTextBox = new System.Windows.Forms.TextBox();
            this.convertButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // celsiusButton
            // 
            this.celsiusButton.AutoSize = true;
            this.celsiusButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.celsiusButton.Location = new System.Drawing.Point(26, 12);
            this.celsiusButton.Name = "celsiusButton";
            this.celsiusButton.Size = new System.Drawing.Size(166, 19);
            this.celsiusButton.TabIndex = 0;
            this.celsiusButton.TabStop = true;
            this.celsiusButton.Text = "Convert to Fareingheit";
            this.celsiusButton.UseVisualStyleBackColor = true;
            // 
            // fareignheitButton
            // 
            this.fareignheitButton.AutoSize = true;
            this.fareignheitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fareignheitButton.Location = new System.Drawing.Point(26, 37);
            this.fareignheitButton.Name = "fareignheitButton";
            this.fareignheitButton.Size = new System.Drawing.Size(140, 19);
            this.fareignheitButton.TabIndex = 1;
            this.fareignheitButton.TabStop = true;
            this.fareignheitButton.Text = "Convert to Celsius";
            this.fareignheitButton.UseVisualStyleBackColor = true;
            // 
            // temperaturelabel
            // 
            this.temperaturelabel.AutoSize = true;
            this.temperaturelabel.Location = new System.Drawing.Point(9, 103);
            this.temperaturelabel.Name = "temperaturelabel";
            this.temperaturelabel.Size = new System.Drawing.Size(70, 13);
            this.temperaturelabel.TabIndex = 2;
            this.temperaturelabel.Text = "Temperature:";
            // 
            // degreesOutputLabel
            // 
            this.degreesOutputLabel.AutoSize = true;
            this.degreesOutputLabel.Location = new System.Drawing.Point(225, 103);
            this.degreesOutputLabel.Name = "degreesOutputLabel";
            this.degreesOutputLabel.Size = new System.Drawing.Size(13, 13);
            this.degreesOutputLabel.TabIndex = 3;
            this.degreesOutputLabel.Text = "0";
            // 
            // degreesLabel
            // 
            this.degreesLabel.AutoSize = true;
            this.degreesLabel.Location = new System.Drawing.Point(169, 103);
            this.degreesLabel.Name = "degreesLabel";
            this.degreesLabel.Size = new System.Drawing.Size(50, 13);
            this.degreesLabel.TabIndex = 4;
            this.degreesLabel.Text = "Degrees:";
            // 
            // temperatureTextBox
            // 
            this.temperatureTextBox.Location = new System.Drawing.Point(85, 96);
            this.temperatureTextBox.Name = "temperatureTextBox";
            this.temperatureTextBox.Size = new System.Drawing.Size(57, 20);
            this.temperatureTextBox.TabIndex = 5;
            // 
            // convertButton
            // 
            this.convertButton.Location = new System.Drawing.Point(12, 157);
            this.convertButton.Name = "convertButton";
            this.convertButton.Size = new System.Drawing.Size(75, 23);
            this.convertButton.TabIndex = 6;
            this.convertButton.Text = "Convert";
            this.convertButton.UseVisualStyleBackColor = true;
            this.convertButton.Click += new System.EventHandler(this.convertButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(161, 157);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // temperatureConverter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(310, 192);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.convertButton);
            this.Controls.Add(this.temperatureTextBox);
            this.Controls.Add(this.degreesLabel);
            this.Controls.Add(this.degreesOutputLabel);
            this.Controls.Add(this.temperaturelabel);
            this.Controls.Add(this.fareignheitButton);
            this.Controls.Add(this.celsiusButton);
            this.Name = "temperatureConverter";
            this.Text = "Celsius an fareignheit Temperature Converter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton celsiusButton;
        private System.Windows.Forms.RadioButton fareignheitButton;
        private System.Windows.Forms.Label temperaturelabel;
        private System.Windows.Forms.Label degreesOutputLabel;
        private System.Windows.Forms.Label degreesLabel;
        private System.Windows.Forms.TextBox temperatureTextBox;
        private System.Windows.Forms.Button convertButton;
        private System.Windows.Forms.Button exitButton;
    }
}

