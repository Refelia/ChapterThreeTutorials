﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingProjects_5
{
    public partial class temperatureConverter : Form
    {
        degree degree = new degree();

        public temperatureConverter()
        {
            InitializeComponent();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            if (celsiusButton.Checked)
            {
                double val = double.Parse(temperatureTextBox.Text);
                degreesOutputLabel.Text = degree.Celsius(val).ToString();
            }
            else if (fareignheitButton.Checked)
            {
                double val = double.Parse(temperatureTextBox.Text);
                degreesOutputLabel.Text = degree.Fareignheit(val).ToString();
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }
}
