﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProgrammingProjects_6
{
    public partial class calculateBodymassIndex : Form
    {

        //Declare variable.
        double weight;
        double height;
        double result;

        public calculateBodymassIndex()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            

            //Set their value.

            weight = double.Parse(weightTextBox.Text);
            height = double.Parse(heightTextBox.Text);

            //Set the value for the result.
            result = (weight * 703) / (height * height);

            //Display the result.
            bmiOutputResultlabel.Text = string.Format("{0:f}", result);



        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }
}
