﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tutorial3_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Using try-catch.

            try
            {
                //Declare the double variable for test1, test2, test3, average.

                double test1;
                double test2;
                double test3;
                double average;

                //Get the three test scores.

                test1 = double.Parse(test1textBox.Text);
                test2 = double.Parse(test2TextBox.Text);
                test3 = double.Parse(test3textBox.Text);

                //Calculate the average test score.

                average = (test1 + test2 + test3) / 3.0;

                //Display the average test score, with the output rounded to 1 decimal point.

                averageLabel.Text = average.ToString("n1");
            }
            catch (Exception xy)
            {
                //Display the default error message.

                MessageBox.Show(xy.Message);
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear the input and output controls

            test1textBox.Text = "";
            test2TextBox.Text = "";
            test3textBox.Text = "";
            averageLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form.

            this.Close();
        }
    }
}
